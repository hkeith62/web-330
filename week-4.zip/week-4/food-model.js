export class FoodModel 
{
    constructor(id, name, calories) {
        this.id = id;
        this.name = name;
        this.calories = calories;
    }
}

// const Food = new FoodModel('23', 'name', '1500');
// console.log(Food.id, Food.name, Food.calories)